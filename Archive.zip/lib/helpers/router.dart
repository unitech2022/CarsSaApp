const categ = "/categoryScreen";
const shop = "/shopscreen";
const nav = "/navigation";
const login = "/loginScreen";
const cars = "/myCarsScreen";
const addCar = "/addCarsScreen";
const edit = "/EditMyProfileScreen";
const details = "/detailsScreen";
const orderProduct = "/orderProduct";
const otpScreen = "/otpScreen";
const methodPay = "/methodPayment";
const myAddress = "/myAddress";
const myOrders = "/MyOrdersScreen";
const fav = "/MyFavScreen";

const welcome = "/welcome";

const addPost = "/addPost";
