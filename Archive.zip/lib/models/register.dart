class Register {
  String? fullName, email, userName, knownName, role, password;

  Register({this.fullName, this.email, this.userName});
}
