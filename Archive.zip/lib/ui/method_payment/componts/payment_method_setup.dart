import 'package:carsa/bloc/cart_cubite/cart_cubit.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_svg/svg.dart';

import '../../../bloc/order_cubit/order_cubit.dart';
import '../../../helpers/functions.dart';
import '../../../helpers/styles.dart';
import '../../../widgets/Texts.dart';
import '../../../widgets/custom_button.dart';
import '../../payment/payment.dart';

class PaymentMethodSetpp extends StatelessWidget {

  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return BlocBuilder<OrderCubit, OrderState>(
      builder: (context, state) {
        return Scaffold(
          body: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: Stack(
              children: [
               Align(
                 alignment: Alignment.topCenter,
                 child: Column(
                   children: [

                     //** payment methods */
                     ContainerRadioButton(
                       title: "الدفع كاش",
                       borderColor: OrderCubit.get(context).payment == 0
                           ? homeColor
                           : const Color(0xffABABB7),
                       image: "assets/icons/cash.svg",
                       color:OrderCubit.get(context).payment == 0
                           ? homeColor
                           : Colors.transparent,
                       onTap: () {
                         OrderCubit.get(context).changePayMentMethod(0);
                       },
                     ),
                     Divider(),
                     ContainerRadioButton(
                       title: "الدفع آونلاين",
                       borderColor: OrderCubit.get(context).payment ==1
                           ? homeColor
                           : const Color(0xffABABB7),
                       image: "assets/icons/cash.svg",
                       color:OrderCubit.get(context).payment == 1
                           ? homeColor
                           : Colors.transparent,
                       onTap: () {
                         OrderCubit.get(context).changePayMentMethod(1);
                       },
                     ),
                   ],
                 ),
               ),
                Align(
                  alignment: Alignment.bottomCenter,
                  child: Padding(
                    padding: const EdgeInsets.only(bottom: 10),
                    child: CustomButton3(
                        text: "التالي",
                        fontFamily: "PNUB",
                        onPress: () {
                          if(OrderCubit.get(context).payment==0){
                            OrderCubit.get(context).changeStepperOrder(2);
                          }else {

                            pushPage(
                                context:context,page:
                                PaymentMethodsConfirmed(

                                  total: ((CartCubit.get(context).total * .15) +
                                      17 +
                                      CartCubit.get(context).total)
                                      .toInt(),
                                  productId: 0,
                                  providerId: 0,
                                  type: 0,
                                  quntity: 0,
                                ));
                          }

                        },
                        redius: 10,
                        color: homeColor,
                        textColor: Colors.white,
                        fontSize: 18,
                        height: 50),
                  ),
                )
              ],
            ),
          ),
        );
      },
    );
  }
}
class ContainerRadioButton extends StatelessWidget {
  final String image, title;
  final Color color, borderColor;
  final void Function() onTap;
  const ContainerRadioButton({

    required this.image,
    required this.title,
    required this.color,
    required this.onTap,
    required this.borderColor,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        height: 70,
        width: double.infinity,
        alignment: Alignment.center,
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Texts(title: title,  fSize: 18,color: homeColor,weight: FontWeight.bold,),
            Container(
              padding: const EdgeInsets.all(2),
              height: 24,
              width: 24,
              decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  border: Border.all(width: 2.5, color: borderColor)),
              child: Container(
                decoration: BoxDecoration(shape: BoxShape.circle, color: color),
              ),
            )
          ],
        ),
      ),
    );
  }
}
