import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_svg/svg.dart';

import 'package:moyasar/moyasar.dart';

import '../../bloc/address_cubit/address_cubit.dart';
import '../../bloc/app_cubit/app_cubit.dart';
import '../../bloc/cart_cubite/cart_cubit.dart';
import '../../bloc/order_cubit/order_cubit.dart';
import '../../helpers/helper_function.dart';
import '../../helpers/router.dart';
import '../../helpers/styles.dart';
import '../../widgets/Texts.dart';

class PaymentMethodsConfirmed extends StatefulWidget {
  final int total, type, productId, providerId, quntity;

  PaymentMethodsConfirmed(
      {
      required this.total,
      this.type = 0,
      required this.productId,

      required this.providerId,
      required this.quntity});

  @override
  State<PaymentMethodsConfirmed> createState() =>
      _PaymentMethodsConfirmedState();
}

class _PaymentMethodsConfirmedState extends State<PaymentMethodsConfirmed> {
  PaymentConfig? paymentConfig;

  @override
  void initState() {
    super.initState();
    print(widget.total);
    paymentConfig = PaymentConfig(
      publishableApiKey: 'pk_test_83UURo8Mjym2nc7jgxKhJLrVKrzgqNhogC5M4RoY',
      amount: widget.total * 100, // SAR 257.58
      description: 'order ',
      metadata: {'size': '250g'},
      // applePay: ApplePayConfig(merchantId: 'YOUR_MERCHANT_ID', label: 'ليموزين'),
    );
  }

  void onPaymentResult(result) {
    if (result is PaymentResponse) {
      switch (result.status) {
        case PaymentStatus.paid:
          print(result.amount);


          break;
        case PaymentStatus.failed:
          // handle failure.
          HelperFunction.slt.notifyUser(
              context: context,
              color: Colors.red,
              message: "فشلت العملية");
          break;
        case PaymentStatus.initiated:
          HelperFunction.slt.notifyUser(
              context: context,
              color: Colors.red,
              message: "فشلت العملية");
          break;
        case PaymentStatus.authorized:
          HelperFunction.slt.notifyUser(
              context: context,
              color: Colors.red,
              message: "فشلت العملية");
          break;
        case PaymentStatus.captured:
          HelperFunction.slt.notifyUser(
              context: context,
              color: Colors.red,
              message: "فشلت العملية");
          break;
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(SystemUiOverlayStyle(
      statusBarColor: Colors.black,
      statusBarBrightness: Brightness.dark,
    ));
    return Scaffold(

      body: Container(
        padding: EdgeInsets.all(20),
        child: SingleChildScrollView(
          child: Column(
            children: [
              SizedBox(
                height:50,
              ),
            Row(
              children: [
                Container(
                  height: 60,
                  width: 60,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle
                  ),

                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(35),
                    child: Image.asset(
                      "assets/images/logo.png",
                      width: 80,
                      height: 80,
                    ),
                  ),
                ),
                SizedBox(width: 10,),
                Texts(
                  title: "Car SA",
                  color: Colors.black,
                  fSize: 28,
                  weight: FontWeight.bold,

                ),
              ],
            ),
              SizedBox(
                height: 30,
              ),

              // ApplePay(
              //   config: paymentConfig,
              //   onPaymentResult: onPaymentResult,
              // ),
              // const Text("or"),
              CreditCard(
                config: paymentConfig!,
                onPaymentResult: onPaymentResult,
              )
            ],
          ),
        ),
      ),
    );
  }
}
