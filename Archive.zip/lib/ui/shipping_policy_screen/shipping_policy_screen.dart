import 'package:flutter/material.dart';
import 'package:flutter_html/flutter_html.dart';

import '../../helpers/data.dart';
import '../../helpers/functions.dart';
import '../../helpers/styles.dart';

class shippingPolicyScreen extends StatelessWidget {
  const shippingPolicyScreen({y});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        elevation: 0,
        backgroundColor: Colors.white,
        automaticallyImplyLeading: true,
        leading: IconButton(
          onPressed: () {
            pop(context);
          },
          icon: const Icon(
            Icons.arrow_back,
            color: homeColor,
          ),
        ),
        title: Text(
         "سياسة الشحن والتوصيل" ,
          style: TextStyle(color: homeColor, fontFamily: "pnuR", fontSize: 16),
        ),
      ),
      body:SingleChildScrollView(
        child: Html(
          data: htmlPolicyShipping,
          style:{
            "h3":Style(
              textAlign: TextAlign.center,
              fontSize: FontSize.xLarge,
              color: Colors.red,
              fontWeight: FontWeight.bold
            ),
            "li":Style(
              color: Colors.black,
              fontWeight: FontWeight.bold
            )
          },
        ),
      ),

    );
  }
}
